git init
git add README.md
git commit -m "first commit"
git branch -M main
git remote add origin git@github.com:jsryu7287/js-homepage.git
git push -u origin main
